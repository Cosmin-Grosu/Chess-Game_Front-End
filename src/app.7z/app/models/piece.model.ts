export class Piece {
    verX: any;
    horY: any;
    startX: any;
    startY: any;
    endX: any;
    endY: any;
    type: any;
    color: any;
    image: any;
}
