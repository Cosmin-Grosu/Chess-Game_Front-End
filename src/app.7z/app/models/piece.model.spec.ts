import { Piece } from './piece.model';

describe('Piece', () => {
  it('should create an instance', () => {
    expect(new Piece()).toBeTruthy();
  });
});
